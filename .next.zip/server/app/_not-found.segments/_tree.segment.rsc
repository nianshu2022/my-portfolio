:HL["/_next/static/chunks/2473c16c0c2f6b5f.css","style"]
:HL["/_next/static/chunks/4f6b1d94181a7c44.css","style"]
0:{"buildId":"sd6d4uUQm4Q5ZS48l62kQ","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
