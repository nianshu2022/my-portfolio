globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/b9a8a4dae22f07d4.js",
    "static/chunks/a30fdccbf8244210.js",
    "static/chunks/3e200bca904262de.js",
    "static/chunks/6f96a97127d7d22c.js",
    "static/chunks/236f7e5abd6f09ff.js",
    "static/chunks/turbopack-b0dc79de0e077adc.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];